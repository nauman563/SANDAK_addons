from . import ks_dashboard_ninja
from . import ks_dashboard_ninja_items
from . import ks_item_action
from . import ks_child_dashboard
from . import ks_dashboard_filters
from . import ks_dashboard_templates
from . import ks_dn_to_do_item
from . import ks_import_dashboard
from . import Kpi_mail
from . import res_settings
from . import ks_ai_ninja_dashboard
from . import ks_ai_whole_dashboard
from . import ks_key_fetch
from . import ks_chat_channel


